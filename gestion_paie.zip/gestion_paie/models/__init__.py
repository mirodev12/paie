# -*- coding: utf-8 -*-

from . import gestion_paie_paies
