# -*- coding: utf-8 -*-
from openerp import api, fields, models
from openerp import tools
from random import randint
import datetime
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from odoo import SUPERUSER_ID
from dateutil import tz
import re

import logging
_logger = logging.getLogger(__name__)


class GestionPaiePaies(models.Model):

    _name = "gestion.paie.paies"
    _description = "Gestion Paie Paies"
    _order = "create_date desc"
    _rec_name ="nom"

    empolyee_id = fields.Char(string="Nom")
    matricule=fields.Date(string="Matricule")
    etat_civil=fields.Char(string="Etat Civil")
    function=fields.Char(string="Function")
    nb_enfant=fields.Integer(string="Nombre Enfant")
    cee=fields.Char(string="Cat - Echelle - Echlon")
    statut=fields.Char(string="statut")
    cin=fields.Char(string="N° Cin")
    mois=fields.Selection([ ('Janv', 'Janv'),('Fevr', 'Fevr'),('Mars', 'Mars'),('Avril', 'Avril'),('Mai', 'Mai'),('Juin', 'Juin'),('Juil', 'Juil'),('Aout', 'Aout'),('Sept', 'Sept'),('Oct', 'Oct'),('Nov', 'Nov'),('Dec', 'Dec'),],'Mois')
    years=fields.Selection([ ('2015', '2015'),('2016', '2016'),('2017', '2017'),('2018', '2018'),('2019', '2019'),('2020', '2020'),('2021', '2021'),('2022', '2022'),('2023', '2023'),('2024', '2024'),('2025', '2025'),('2026', '2026'),],'Année')
    @api.onchange('empolyee_id')
    def _onchange_employee(self):
        matricule=employee_id.
        etat_civil=employee_id.marital
        function=employee_id.job_title
        nb_enfant=employee_id.children
        cin=employee_id.ssnid